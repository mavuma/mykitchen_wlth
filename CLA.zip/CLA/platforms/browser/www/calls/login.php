<?php
session_start();
$_SESSION["user"] = $_POST['username'];
error_reporting(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ALL & ~E_NOTICE);



$id = $_POST['pws'];	
$dt = Date('d/m/y');
$userkeys;
$username;
$server = mysqli_connect("localhost","admin","")or die("db connection not established");
mysqli_query($server, "use test");
$query = mysqli_query($server, "select * from userdetails where pws='$id'");
while($result = mysqli_fetch_array($query))
					{
						$userkeys = $result['pws'];
						$username = $result['username'];
						
					}
						if($userkeys == $_POST['pws'] AND $username == $_POST['username']){
						$query = mysqli_query($server, "select * from logfile");
						mysqli_query($server, "INSERT INTO logfile(username, dt)
						VALUES
						('$_POST[username]',
						'$dt')") or die("user information not saved");
						if($userkeys == $_POST['pws'] || $username == $_POST['username']){
						$query = mysqli_query($server, "select * from logfile");
						mysqli_query($server, "INSERT INTO logfile(username, dt)
						VALUES
						('$_POST[username]',
						'$dt')") or die("user information not saved");
						print "<script type='text/javascript'> alert('User accepted');
						window.location.href = 'main.php';</script>";} }else
						{print "<script type='text/javascript'> alert('Wrong loging details');
						window.location.href = '/log app/login.html';</script>"; } 
	



?>