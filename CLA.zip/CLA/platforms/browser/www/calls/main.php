<?php
session_start();
$connection = $_SESSION["user"];
error_reporting(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ALL & ~E_NOTICE);
$call = $_POST['call'];
$comment = $_POST['comments'];
$cord = $_POST['cord'];
$dt = Date('d/m/y');
$reff = rand(10, 10000);
$ip = $_SERVER['REMOTE_ADDR'];
$info = $_SERVER["HTTP_USER_AGENT"];


$server = mysqli_connect("localhost","admin","")or die("db connection not established");
mysqli_query($server, "use test");
$query = mysqli_query($server, "select * from userdetails where username = '$_SESSION[user]'")
or die("user data error");
while($result = mysqli_fetch_array($query))
		{
			$name = $result['name'];
			$username = $result['username'];
			$location = $result['Location'];
			$contact = $result['contact'];	
			
		}

function calltable()
{
$server = mysqli_connect("localhost","admin","")or die("db connection not established");
mysqli_query($server, "use test");
$query = mysqli_query($server, "select open from calltable");
while($result = mysqli_fetch_array($query))
{ $opencalls = $result['open']; $x = $opencalls +1;}
mysqli_query($server,"UPDATE calltable SET 
open='$x'")or die("updating calltable error updating");
}

if($call != null && $comment != null)
{
$server = mysqli_connect("localhost","admin","")or die("db connection not established");
mysqli_query($server, "use test");
$query = mysqli_query($server, "select * from complainlog");
$target_dir = "dashboard/uploads/";
$newDB ="uploads/";
$target_file = $target_dir . basename($_FILES["proof"]["name"]);
$newDB_file = $newDB. basename($_FILES["proof"]["name"]); 
$uploadOk = 1;
$rootfile = $target_file;
$type = "Mobilephone";

if (move_uploaded_file($_FILES["proof"]["tmp_name"], $target_file)) {
        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

	$to = "$contact@mymobileapi.com";
	$subject = "[un=e-bill][pw=mduduzi05871311]";
	$message = "Your complain has been send Ref: $reff. Thank you for using our App";
	mail($to, $subject, $message);

mysqli_query($server, "INSERT INTO complainlog(username, name, location, problem, comment, contact, dt, status, image, ref6, ip6, info, cordinates, type, Department)
VALUES
('$username',
'$name',
'$location',
'$call',
'$comment',
'$contact',
'$dt',
'Open',
'$newDB_file',
'$reff',
'$ip',
'$info',
'$cord',
'$type',
'Data')") or die("user information not saved");
calltable();
print "<script type='text/javascript'> alert('You call is loged $cord');
	window.location.href = '/log app/main.html';</script>";
print "";
}else
{print "<script type='text/javascript'> alert('Provide all neccessary details');
	window.location.href = '/log app/main.html';</script>";}


?>