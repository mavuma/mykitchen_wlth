<?php
error_reporting(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ALL & ~E_NOTICE);

if($_POST['name'] != null && $_POST['contact'] != null && $_POST['location'] && $_POST['pws'] && $_POST['username'])
{
$dt = Date('d/m/y');
$server = mysqli_connect("localhost","admin","")or die("db connection not established");
mysqli_query($server, "use test");
$query = mysqli_query($server, "select * from userdetails");
mysqli_query($server, "INSERT INTO userdetails(name, contact, email, Location, pws, username, dt)
VALUES
('$_POST[name]',
'$_POST[contact]',
'$_POST[email]',
'$_POST[location]',
'$_POST[pws]',
'$_POST[username]',
'$dt')") or die("user information not saved");
print "<script type='text/javascript'> alert('Thank you for using our App');
	window.location.href = '/log app/login.html';</script>";
}else
{
	print "<script type='text/javascript'> alert('Provide all neccessary details');
	window.location.href = '/log app/register.html';</script>";}
	
?>